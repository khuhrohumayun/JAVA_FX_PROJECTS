# Simple-pos-System-KFC V 1.1.5
Simple pos System like KFC cafe fastfood shop


https://github.com/coolsasindu/Simple-pos-System-KFC/assets/45946252/85c2a841-fabd-42f5-832e-f4d916c07cc0


youtu.be/gDbuwFkEdUQ
![poskfc](https://user-images.githubusercontent.com/45946252/170657457-3f6de768-c865-4520-aa8f-8837fb23fcd4.jpg)
